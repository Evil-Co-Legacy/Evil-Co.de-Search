<?php
// wcf imports
require_once(WCF_DIR.'lib/page/MultipleLinkPage.class.php');
require_once(WCF_DIR.'lib/data/search/SearchType.class.php');

class SearchForm extends MultipleLinkPage {
	public $templateName = 'search';
	
	public $advancedSearchFields = array();
	public $searchType = 0;
	public $query = "";
	
	public $searchResults = array();
	
	public function readData() {
		// read parameters
		if (isset($_REQUEST['query'])) $this->query = StringUtil::trim($_REQUEST['query']);
		if (isset($_REQUEST['searchType'])) $this->searchType = intval($_REQUEST['searchType']);
		if (isset($_REQUEST['advancedSearch'])) $this->advancedSearchFields = array_map(array('StringUtil', 'trim'), $_REQUEST['advancedSearch']);
		
		if (isset($_REQUEST['itemsPerPage']) and intval($_REQUEST['itemsPerPage']) <= 100) $this->itemsPerPage = intval($_REQUEST['itemsPerPage']);
		
		// validate
		$this->searchType = new SearchType($this->searchType);
		$className = $this->searchType->typeName;
		
		if ($this->searchType->typeID == 0) {
			HeaderUtil::redirect('index.php?page=Index&error=1&errorMessage=invalidSearchType'.SID_ARG_2ND_NOT_ENCODED);
			exit;
		}
		
		if (!file_exists(WWW_DIR.'lib/data/search/'.$className.'.class.php'))
				throw new SystemException('Classfile \''.$className.'.class.php\' not found.');
			else
				require_once(WWW_DIR.'lib/data/search/'.$className.'.class.php');
		
		$this->searchType = new $className($this->searchType->typeID);
		
		if (count($this->advancedSearchFields)) {
			foreach($this->advancedSearchFields as $field => $value) {
				if (!in_array($field, $this->searchType->getAdvancedSearchFields()) or empty($value)) {
					unset($this->advancedSearchFields[$field]); // delete bad fields
				}
			}
		}
		
		if (empty($this->query) && !count($this->advancedSearchFields)) {
			HeaderUtil::redirect('index.php?page=Index&error=1&errorMessage=noQuerySet'.SID_ARG_2ND_NOT_ENCODED);
			exit;
		}
		
		if (!count($this->advancedSearchFields)) {
			$this->searchResults = $this->searchType->search($this->query, $this->pageNo, $this->itemsPerPage);
		} else {
			$this->searchResults = $this->searchType->advancedSearch($this->query, $this->advancedSearchFields, $this->pageNo, $this->itemsPerPage);
		}
		
		parent::readData();
	}
	
	public function countItems() {
		parent::countItems();
		
		return ($this->searchType ? $this->searchType->getResultCount() : 0);		
	}
	
	public function assignVariables() {
		parent::assignVariables();
		
		WCF::getTPL()->assign(array('results' => $this->searchResults,
									'encodedQuery' => urlencode($this->query),
									'query' => $this->query,
									'searchType' => $this->searchType));
		
		WCF::getTPL()->append('additionalFooterOptions', '<li><a href="index.php?page=Index'.SID_ARG_2ND.'">'.WCF::getLanguage()->get('www.search.result.back').'</a>');
	}
}
?>