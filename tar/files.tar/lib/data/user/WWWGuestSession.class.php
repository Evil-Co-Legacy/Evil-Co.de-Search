<?php
require_once(WWW_DIR.'lib/data/user/AbstractWWWUserSession.class.php');

class WWWGuestSession extends AbstractWWWUserSession {
	
}
?>
