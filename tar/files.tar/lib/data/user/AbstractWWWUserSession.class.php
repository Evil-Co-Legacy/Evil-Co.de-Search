<?php
// wcf imports
require_once(WCF_DIR.'lib/system/session/UserSession.class.php');

/**
 * This class implements a user session
 * @author akkarin
 */
class AbstractWWWUserSession extends UserSession {

}
?>
