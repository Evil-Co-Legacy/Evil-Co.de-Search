<?php
require_once(WCF_DIR.'lib/data/user/UserProfile.class.php');

class WWWUser extends UserProfile {
	
}
?>
