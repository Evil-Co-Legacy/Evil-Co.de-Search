<?php
// wcf imports
require_once(WCF_DIR.'lib/page/AbstractPage.class.php');

class APIPage extends AbstractPage {
	public $templateName = 'api';
	
	public $validActions = array('Download', 'Mirror', 'GetAdvancedSearchFields', 'Search');
	public $validTypes = array('json', 'xml', 'html');
	
	public $type = 'json';
	
	public function readParameters() {
		parent::readParameters();
		
		if (isset($_REQUEST['type'])) $this->type = StringUtil::trim($_REQUEST['type']);
	}
	
	public function show() {
		header('Content-Type: '.($this->type == 'xml' ? 'application/xml' : ($this->type == 'json' ? 'application/json' : 'text/html')));
		$this->readParameters();
		
		if (!in_array($this->action, $this->validActions) or !in_array($this->type, $this->validTypes)) throw new IllegalLinkException;
		
		$functionName = $this->type.$this->action;
		$this->templateName .= ucfirst($this->type).$this->action;
		
		$this->{$functionName}();

		$this->assignVariables();
		echo WCF::getTPL()->fetch($this->templateName);
	}
	
	protected function jsonDownload() {
		if (!isset($_REQUEST['packageID']) or !isset($_REQUEST['version'])) throw new IllegalLinkException;
		$packageID = urldecode($_REQUEST['packageID']);
		$targetVersion = urldecode($_REQUEST['version']);
		
		$sql = "SELECT
					*
				FROM
					`package`
				WHERE
					packageID = '".escapeString($packageID)."'
				AND
					isDeleted = 0";
		$package = WCF::getDB()->getFirstRow($sql);
		
		if (WCF::getDB()->countRows()) {
			$versions = unserialize($package['versions']);
			
			foreach($versions as $version) {
				if ($version['version'] == $targetVersion) {
					//if (!isset($version['notMirrored'])) { // this is for mirrors :-)
					@header("Content-type: text/html");
					// redirect to url
					WCF::getTPL()->assign(array(
						'url' => $version['file'],
						'message' => WCF::getLanguage()->get('www.download.redirect'),
						'wait' => 5
					));
					WCF::getTPL()->display('redirect');
					exit;
					//}
				}
			}
			
			throw new IllegalLinkException;
		} else throw new IllegalLinkException;
	}
	
	protected function jsonMirror() {
		throw new NamedUserException(WCF::getLanguage()->get('www.mirror.notImplemented'));
	}
	
	protected function htmlSearch() {
		require_once(WCF_DIR.'lib/data/search/SearchType.class.php');
		
		$searchResults = array();
		
		if (isset($_REQUEST['query']) and !empty($_REQUEST['query']) and isset($_REQUEST['searchType'])) {
			$searchType = intval($_REQUEST['searchType']);
			$query = StringUtil::trim($_REQUEST['query']);
			if (isset($_REQUEST['page']))
				$page = intval($_REQUEST['page']);
			else
				$page = 1;
				
			if (isset($_REQUEST['itemsPerPage']) and intval($_REQUEST['itemsPerPage']) <= 100)
				$itemsPerPage = intval($_REQUEST['itemsPerPage']);
			else
				$itemsPerPage = 20;
			
			// validate
			$searchType = new SearchType($searchType);
			$className = $searchType->typeName;
			
			if ($searchType->typeID != 0) {
				if (file_exists(WWW_DIR.'lib/data/search/'.$className.'.class.php')) {
					require_once(WWW_DIR.'lib/data/search/'.$className.'.class.php');
					
					$searchType = new $className($searchType->typeID);
					
					$searchResults = $searchType->search($query, $page, $itemsPerPage);
					
					$pageData = $this->calculateNumberOfPages($searchType->getResultCount(), $page, $itemsPerPage);
					
					WCF::getTPL()->assign($pageData);
				} else {
					echo '<p class="error">Cannot load search type</p>';
				}
			} else {
				echo '<p class="error">Invalid SearchType!</p>';
			}
		} else {
			echo '<p class="error">Invalid query!<br />'; print_r($_REQUEST); echo '</p>';
		}
		
		WCF::getTPL()->assign('results', $searchResults);
	}
	
	
	
	/**
	 * Calculates the number of pages and
	 * handles the given page number parameter.
	 */
	public function calculateNumberOfPages($items, $pageNo, $itemsPerPage) {
		// calculate number of pages
		$pages = intval(ceil($items / $itemsPerPage));
		
		// correct active page number
		if ($pageNo > $pages) $pageNo = $pages;
		if ($pageNo < 1) $pageNo = 1;
		
		return array('pageNo' => $pageNo, 'pages' => $pages, 'items' => $items, 'itemsPerPage' => $itemsPerPage);
	}
}
?>